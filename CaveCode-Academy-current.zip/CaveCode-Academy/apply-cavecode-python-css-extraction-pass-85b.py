#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import shutil
import sys


TARGET = Path("Pages/Python.razor")
CSS_TARGET = Path("wwwroot/css/python-course.css")
BACKUP = Path(".python-css-extraction-pass-85b-backup")
MARKER = "CAVECODE_PYTHON_CSS_EXTRACTION_85B"


def find_root() -> Path:
    root = Path.cwd().resolve()

    while root.parent != root and not (root / "CaveCode.csproj").is_file():
        root = root.parent

    if not (root / "CaveCode.csproj").is_file():
        raise RuntimeError(
            "Could not find CaveCode.csproj. "
            "Run this from /workspaces/CaveCode-Academy."
        )

    return root


def backup(root: Path, relative: Path) -> None:
    source = root / relative
    destination = root / BACKUP / relative
    destination.parent.mkdir(parents=True, exist_ok=True)

    if source.exists() and not destination.exists():
        shutil.copy2(source, destination)


def normalize_razor_css(css: str) -> str:
    # Razor requires @@media inside component markup. External CSS requires @media.
    css = css.replace("@@media", "@media")
    css = css.replace("@@keyframes", "@keyframes")
    css = css.replace("@@supports", "@supports")
    css = css.replace("@@container", "@container")
    css = css.replace("@@font-face", "@font-face")
    return css.strip() + "\n"


def main() -> None:
    root = find_root()
    target_path = root / TARGET
    css_path = root / CSS_TARGET

    if not target_path.is_file():
        raise RuntimeError(f"Missing {TARGET}")

    text = target_path.read_text(encoding="utf-8")

    if MARKER in text and css_path.is_file():
        print("Python CSS Extraction Pass 85B is already installed.")
        return

    style_matches = list(
        re.finditer(
            r"<style(?:\s[^>]*)?>(.*?)</style>",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )
    )

    if len(style_matches) != 1:
        raise RuntimeError(
            f"Expected exactly one embedded <style> block in {TARGET}; "
            f"found {len(style_matches)}."
        )

    style_match = style_matches[0]
    raw_css = style_match.group(1)
    css_lines = len(raw_css.splitlines())

    if css_lines < 500:
        raise RuntimeError(
            f"Embedded CSS block is unexpectedly small ({css_lines} lines). "
            "The page structure may have changed."
        )

    required_tokens = [
        ".sidebar",
        ".course-nav",
        ".lesson-main",
        ".stage-tabs",
        ".preview-panel",
        ".terminal",
    ]

    missing = [token for token in required_tokens if token not in raw_css]

    if missing:
        raise RuntimeError(
            "Embedded Python course CSS is missing expected selectors: "
            + ", ".join(missing)
        )

    backup(root, TARGET)
    backup(root, CSS_TARGET)

    external_css = (
        f"/* {MARKER} */\n"
        "/* Extracted from Pages/Python.razor. Visual rules only. */\n\n"
        + normalize_razor_css(raw_css)
    )

    link_markup = (
        f'<!-- {MARKER} -->\n'
        '<link rel="stylesheet" href="css/python-course.css?v=85b" />'
    )

    repaired = (
        text[:style_match.start()]
        + link_markup
        + text[style_match.end():]
    )

    checks = {
        "inline style removed":
            "<style" not in repaired.lower(),
        "stylesheet reference added":
            'css/python-course.css?v=85b' in repaired,
        "marker added":
            MARKER in repaired,
        "route preserved":
            re.search(r'@page\s+"[^"]*python[^"]*"', repaired, re.I)
            is not None,
        "code block preserved":
            "@code" in repaired,
        "lesson state preserved":
            "List<Lesson> Lessons" in repaired,
        "validation preserved":
            "CheckCode" in repaired,
        "progression preserved":
            "FinishModule" in repaired,
        "save behavior preserved":
            "SaveProgressAsync" in repaired,
        "responsive CSS converted":
            "@@media" not in external_css
            and "@media" in external_css,
    }

    failed = [name for name, passed in checks.items() if not passed]

    if failed:
        raise RuntimeError(
            "Validation failed: " + ", ".join(failed)
        )

    css_path.parent.mkdir(parents=True, exist_ok=True)
    css_path.write_text(
        external_css,
        encoding="utf-8",
        newline="\n",
    )

    target_path.write_text(
        repaired,
        encoding="utf-8",
        newline="\n",
    )

    removed_lines = css_lines - len(link_markup.splitlines())

    print("Python CSS Extraction Pass 85B completed.")
    print()
    print(f"Extracted CSS lines: {css_lines}")
    print(f"Approximate Python.razor line reduction: {removed_lines}")
    print(f"New stylesheet: {CSS_TARGET}")
    print()
    print("Protected:")
    print("  - Python course route")
    print("  - lessons and module identifiers")
    print("  - progression and mastery")
    print("  - XP and chapter rewards")
    print("  - validation and hints")
    print("  - resume and save behavior")
    print("  - all page methods and state fields")
    print()
    print(f"Backup: {BACKUP}/")
    print()
    print("Next commands:")
    print("  dotnet build")
    print("  dotnet run")
    print()
    print("Test:")
    print("  1. Open the Python course.")
    print("  2. Confirm the page looks identical.")
    print("  3. Move between modules and stages.")
    print("  4. Run one code validation.")
    print("  5. Refresh and confirm progress resumes.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
