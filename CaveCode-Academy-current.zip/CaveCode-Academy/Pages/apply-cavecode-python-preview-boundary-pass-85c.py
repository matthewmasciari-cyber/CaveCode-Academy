#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import shutil
import sys


TARGET = Path("Pages/Python.razor")
COMPONENT = Path("Components/PythonCourse/PythonPreviewPanel.razor")
BACKUP = Path(".python-preview-boundary-pass-85c-backup")
MARKER = "CAVECODE_PYTHON_PREVIEW_BOUNDARY_85C"

COMPONENT_TEXT = '@* CAVECODE_PYTHON_PREVIEW_BOUNDARY_85C\n   Structural wrapper only. The parent still owns all state and event handlers. *@\n\n<aside class="preview-panel">\n    @ChildContent\n</aside>\n\n@code {\n    [Parameter]\n    public RenderFragment? ChildContent { get; set; }\n}\n'


def find_root() -> Path:
    root = Path.cwd().resolve()

    while root.parent != root and not (root / "CaveCode.csproj").is_file():
        root = root.parent

    if not (root / "CaveCode.csproj").is_file():
        raise RuntimeError(
            "Could not find CaveCode.csproj. "
            "Run this from /workspaces/CaveCode-Academy."
        )

    return root


def backup(root: Path, relative: Path) -> None:
    source = root / relative
    destination = root / BACKUP / relative
    destination.parent.mkdir(parents=True, exist_ok=True)

    if source.exists() and not destination.exists():
        shutil.copy2(source, destination)


def find_matching_aside(text: str, start: int) -> tuple[int, int]:
    token_pattern = re.compile(
        r"</?aside\b[^>]*>",
        flags=re.IGNORECASE,
    )

    depth = 0

    for match in token_pattern.finditer(text, start):
        token = match.group(0)

        if token.lower().startswith("</aside"):
            depth -= 1

            if depth == 0:
                return match.start(), match.end()
        else:
            depth += 1

    raise RuntimeError(
        "Could not find the matching closing </aside> for preview-panel."
    )


def main() -> None:
    root = find_root()
    target_path = root / TARGET
    component_path = root / COMPONENT

    if not target_path.is_file():
        raise RuntimeError(f"Missing {TARGET}")

    text = target_path.read_text(encoding="utf-8")

    if MARKER in text and component_path.is_file():
        print("Python Preview Boundary Pass 85C is already installed.")
        return

    opening_pattern = re.compile(
        r'<aside\s+class="preview-panel"\s*>',
        flags=re.IGNORECASE,
    )

    matches = list(opening_pattern.finditer(text))

    if len(matches) != 1:
        raise RuntimeError(
            "Expected exactly one <aside class=\"preview-panel\">; "
            f"found {len(matches)}."
        )

    opening = matches[0]
    closing_start, closing_end = find_matching_aside(
        text,
        opening.start(),
    )

    inner = text[opening.end():closing_start]

    required_tokens = [
        "preview-header",
        "inventory-card",
        "terminal",
    ]

    missing = [token for token in required_tokens if token not in inner]

    if missing:
        raise RuntimeError(
            "Preview panel is missing expected content: "
            + ", ".join(missing)
        )

    replacement = (
        f'@* {MARKER} *@\n'
        '<PythonPreviewPanel>'
        + inner
        + '</PythonPreviewPanel>'
    )

    repaired = (
        text[:opening.start()]
        + replacement
        + text[closing_end:]
    )

    checks = {
        "component invocation added":
            "<PythonPreviewPanel>" in repaired
            and "</PythonPreviewPanel>" in repaired,
        "old aside removed":
            '<aside class="preview-panel">' not in repaired,
        "preview content preserved":
            all(token in repaired for token in required_tokens),
        "route preserved":
            re.search(r'@page\s+"[^"]*python[^"]*"', repaired, re.I)
            is not None,
        "state preserved":
            "List<Lesson> Lessons" in repaired,
        "validation preserved":
            "CheckCode" in repaired,
        "progression preserved":
            "FinishModule" in repaired,
        "save preserved":
            "SaveProgressAsync" in repaired,
        "marker added":
            MARKER in repaired,
        "wrapper renders semantic aside":
            '<aside class="preview-panel">' in COMPONENT_TEXT,
        "child content parameter":
            "RenderFragment? ChildContent" in COMPONENT_TEXT,
    }

    failed = [name for name, passed in checks.items() if not passed]

    if failed:
        raise RuntimeError(
            "Validation failed: " + ", ".join(failed)
        )

    backup(root, TARGET)
    backup(root, COMPONENT)

    component_path.parent.mkdir(parents=True, exist_ok=True)
    component_path.write_text(
        COMPONENT_TEXT,
        encoding="utf-8",
        newline="\n",
    )

    target_path.write_text(
        repaired,
        encoding="utf-8",
        newline="\n",
    )

    print("Python Preview Boundary Pass 85C completed.")
    print()
    print(f"Created: {COMPONENT}")
    print(f"Updated: {TARGET}")
    print()
    print("What changed:")
    print("  - preview-panel is now rendered by PythonPreviewPanel")
    print("  - existing preview markup remains authored in Python.razor")
    print("  - existing bindings and event handlers remain in parent scope")
    print("  - semantic <aside class=\"preview-panel\"> output is preserved")
    print()
    print("Protected:")
    print("  - simulation state")
    print("  - inventory values")
    print("  - terminal output")
    print("  - stage controls")
    print("  - progression, XP, validation, saving, and resume behavior")
    print()
    print(f"Backup: {BACKUP}/")
    print()
    print("Next commands:")
    print("  dotnet build")
    print("  dotnet run")
    print()
    print("Test:")
    print("  1. Open the Python course.")
    print("  2. Confirm the preview appears unchanged.")
    print("  3. Use any preview controls.")
    print("  4. Validate one exercise.")
    print("  5. Refresh and confirm progress remains.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
