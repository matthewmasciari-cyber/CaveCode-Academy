#!/usr/bin/env python3
from pathlib import Path
import re
import shutil

root = Path.cwd()

required = [
    root / "Pages" / "Home.razor",
    root / "Pages" / "CSharp.razor",
    root / "Pages" / "Python.razor",
    root / "Pages" / "Settings.razor",
    root / "Components" / "AuthPanel.razor",
    root / "Program.cs",
    root / "_Imports.razor",
    root / "wwwroot" / "index.html",
]

missing = [str(path.relative_to(root)) for path in required if not path.exists()]
if missing:
    raise SystemExit(
        "Run this installer from the CaveCode repository root. Missing: "
        + ", ".join(missing)
    )

backup = root / ".achievements-crystals-backup"
backup.mkdir(exist_ok=True)

for relative in [
    Path("Pages/Home.razor"),
    Path("Pages/CSharp.razor"),
    Path("Pages/Python.razor"),
    Path("Pages/Settings.razor"),
    Path("Pages/Achievements.razor"),
    Path("Components/AuthPanel.razor"),
    Path("Components/AchievementNavLink.razor"),
    Path("Components/ProgressIdentity.razor"),
    Path("Services/AchievementService.cs"),
    Path("Program.cs"),
    Path("_Imports.razor"),
    Path("wwwroot/index.html"),
    Path("wwwroot/js/caveCodeAchievements.js"),
]:
    source = root / relative
    if source.exists():
        destination = backup / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

achievement_service = r'''using Microsoft.JSInterop;
using System.Text.Json.Serialization;

namespace CaveCode.Services;

public sealed class AchievementService(IJSRuntime js)
{
    public ValueTask<AchievementState> GetStateAsync() =>
        js.InvokeAsync<AchievementState>(
            "caveCodeAchievements.getState"
        );

    public ValueTask<AchievementState> ClaimAsync(string achievementId) =>
        js.InvokeAsync<AchievementState>(
            "caveCodeAchievements.claim",
            achievementId
        );

    public ValueTask<AchievementUnlockResult?> UnlockChapterAsync(
        string course,
        int chapter
    ) =>
        js.InvokeAsync<AchievementUnlockResult?>(
            "caveCodeAchievements.unlockChapter",
            course,
            chapter
        );

    public ValueTask<TitleUnlockOption[]> GetTitleOptionsAsync() =>
        js.InvokeAsync<TitleUnlockOption[]>(
            "caveCodeAchievements.getTitleOptions"
        );

    public ValueTask<AchievementFeatureOption[]>
        GetFeatureOptionsAsync() =>
        js.InvokeAsync<AchievementFeatureOption[]>(
            "caveCodeAchievements.getFeatureOptions"
        );
}

public sealed class AchievementState
{
    [JsonPropertyName("crystals")]
    public int Crystals { get; set; }

    [JsonPropertyName("unclaimedCount")]
    public int UnclaimedCount { get; set; }

    [JsonPropertyName("earnedCount")]
    public int EarnedCount { get; set; }

    [JsonPropertyName("claimedCount")]
    public int ClaimedCount { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("achievements")]
    public AchievementRecord[] Achievements { get; set; } =
        Array.Empty<AchievementRecord>();
}

public sealed class AchievementRecord
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = "";

    [JsonPropertyName("course")]
    public string Course { get; set; } = "";

    [JsonPropertyName("courseName")]
    public string CourseName { get; set; } = "";

    [JsonPropertyName("chapter")]
    public int Chapter { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = "";

    [JsonPropertyName("description")]
    public string Description { get; set; } = "";

    [JsonPropertyName("titleReward")]
    public string TitleReward { get; set; } = "";

    [JsonPropertyName("crystals")]
    public int Crystals { get; set; }

    [JsonPropertyName("unlocked")]
    public bool Unlocked { get; set; }

    [JsonPropertyName("claimed")]
    public bool Claimed { get; set; }
}

public sealed class AchievementUnlockResult
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = "";

    [JsonPropertyName("course")]
    public string Course { get; set; } = "";

    [JsonPropertyName("chapter")]
    public int Chapter { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = "";

    [JsonPropertyName("description")]
    public string Description { get; set; } = "";

    [JsonPropertyName("titleReward")]
    public string TitleReward { get; set; } = "";

    [JsonPropertyName("crystals")]
    public int Crystals { get; set; }

    [JsonPropertyName("newlyUnlocked")]
    public bool NewlyUnlocked { get; set; }
}

public sealed class TitleUnlockOption
{
    [JsonPropertyName("title")]
    public string Title { get; set; } = "";

    [JsonPropertyName("unlocked")]
    public bool Unlocked { get; set; }

    [JsonPropertyName("requirement")]
    public string Requirement { get; set; } = "";
}

public sealed class AchievementFeatureOption
{
    [JsonPropertyName("name")]
    public string Name { get; set; } = "";

    [JsonPropertyName("unlocked")]
    public bool Unlocked { get; set; }

    [JsonPropertyName("requirement")]
    public string Requirement { get; set; } = "";
}
'''

achievement_js = r'''(function () {
    const storageKey = "cavecode.achievements.v1";

    const definitions = [
        {
            id: "csharp-chapter-1",
            course: "csharp",
            courseName: "C# Cave Adventure",
            chapter: 1,
            name: "Cave Entrance Opened",
            description: "Complete C# Chapter 1 and establish your coding foundation.",
            titleReward: "Code Apprentice",
            crystals: 100
        },
        {
            id: "csharp-chapter-2",
            course: "csharp",
            courseName: "C# Cave Adventure",
            chapter: 2,
            name: "Logic Torch Lit",
            description: "Complete C# Chapter 2 and master decisions and control flow.",
            titleReward: "Logic Pathfinder",
            crystals: 125
        },
        {
            id: "csharp-chapter-3",
            course: "csharp",
            courseName: "C# Cave Adventure",
            chapter: 3,
            name: "Explorer's Toolkit",
            description: "Complete C# Chapter 3 and build reusable systems and collections.",
            titleReward: "Systems Builder",
            crystals: 150
        },
        {
            id: "csharp-chapter-4",
            course: "csharp",
            courseName: "C# Cave Adventure",
            chapter: 4,
            name: "Creature Architect",
            description: "Complete C# Chapter 4 and shape the cave game's living systems.",
            titleReward: "C# Adventurer",
            crystals: 175
        },
        {
            id: "csharp-chapter-5",
            course: "csharp",
            courseName: "C# Cave Adventure",
            chapter: 5,
            name: "Cave Adventure Master",
            description: "Complete the full C# Cave Adventure learning path.",
            titleReward: "CaveCode Champion",
            crystals: 250
        },
        {
            id: "python-chapter-1",
            course: "python",
            courseName: "Python Automation Quest",
            chapter: 1,
            name: "Control Terminal Online",
            description: "Complete Python Chapter 1 and restore the underground control room.",
            titleReward: "Control Room Operator",
            crystals: 100
        },
        {
            id: "python-chapter-2",
            course: "python",
            courseName: "Python Automation Quest",
            chapter: 2,
            name: "Safety Systems Certified",
            description: "Complete Python Chapter 2 and commission the safety logic.",
            titleReward: "Safety Technician",
            crystals: 125
        },
        {
            id: "python-chapter-3",
            course: "python",
            courseName: "Python Automation Quest",
            chapter: 3,
            name: "Sequence Controller Online",
            description: "Complete Python Chapter 3 and automate repeated equipment sequences.",
            titleReward: "Automation Trainee",
            crystals: 150
        },
        {
            id: "python-chapter-4",
            course: "python",
            courseName: "Python Automation Quest",
            chapter: 4,
            name: "Monitoring Network Established",
            description: "Complete Python Chapter 4 and reconnect the facility monitoring network.",
            titleReward: "Systems Monitor",
            crystals: 175
        },
        {
            id: "python-chapter-5",
            course: "python",
            courseName: "Python Automation Quest",
            chapter: 5,
            name: "Python Automation Technician",
            description: "Complete the full Python Automation Quest learning path.",
            titleReward: "Python Technician",
            crystals: 250
        }
    ];

    function emptyState() {
        return {
            unlocked: [],
            claimed: [],
            crystals: 0
        };
    }

    function load() {
        try {
            const parsed = JSON.parse(
                localStorage.getItem(storageKey) || "{}"
            );

            return {
                unlocked: Array.isArray(parsed.unlocked)
                    ? parsed.unlocked
                    : [],
                claimed: Array.isArray(parsed.claimed)
                    ? parsed.claimed
                    : [],
                crystals: Number.isFinite(parsed.crystals)
                    ? Math.max(0, Math.floor(parsed.crystals))
                    : 0
            };
        } catch {
            return emptyState();
        }
    }

    function save(state) {
        localStorage.setItem(
            storageKey,
            JSON.stringify(state)
        );

        window.dispatchEvent(
            new CustomEvent(
                "cavecode-achievements-changed",
                { detail: buildView(state) }
            )
        );
    }

    function progressSnapshot(course) {
        const key = `cavecode.${course}.progress.v1`;

        try {
            return JSON.parse(
                localStorage.getItem(key) || "null"
            );
        } catch {
            return null;
        }
    }

    function completedModules(snapshot) {
        if (!snapshot) {
            return [];
        }

        const modules =
            snapshot.moduleCompleted ??
            snapshot.ModuleCompleted ??
            [];

        return Array.isArray(modules) ? modules : [];
    }

    function syncFromCourseProgress(state) {
        let changed = false;

        for (const course of ["csharp", "python"]) {
            const modules = completedModules(
                progressSnapshot(course)
            );

            for (let chapter = 1; chapter <= 5; chapter++) {
                const finalModuleIndex = chapter * 8 - 1;
                const definition = definitions.find(
                    item =>
                        item.course === course &&
                        item.chapter === chapter
                );

                if (
                    definition &&
                    modules[finalModuleIndex] === true &&
                    !state.unlocked.includes(definition.id)
                ) {
                    state.unlocked.push(definition.id);
                    changed = true;
                }
            }
        }

        if (changed) {
            save(state);
        }

        return state;
    }

    function buildView(state) {
        const achievements = definitions.map(definition => ({
            ...definition,
            unlocked: state.unlocked.includes(definition.id),
            claimed: state.claimed.includes(definition.id)
        }));

        return {
            crystals: state.crystals,
            unclaimedCount: achievements.filter(
                item => item.unlocked && !item.claimed
            ).length,
            earnedCount: achievements.filter(
                item => item.unlocked
            ).length,
            claimedCount: achievements.filter(
                item => item.claimed
            ).length,
            totalCount: achievements.length,
            achievements
        };
    }

    function currentView() {
        const state = syncFromCourseProgress(load());
        return buildView(state);
    }

    window.caveCodeAchievements = {
        getState: function () {
            return currentView();
        },

        unlockChapter: function (course, chapter) {
            const definition = definitions.find(
                item =>
                    item.course === String(course) &&
                    item.chapter === Number(chapter)
            );

            if (!definition) {
                return null;
            }

            const state = load();
            const newlyUnlocked =
                !state.unlocked.includes(definition.id);

            if (newlyUnlocked) {
                state.unlocked.push(definition.id);
                save(state);
            }

            return {
                ...definition,
                newlyUnlocked
            };
        },

        claim: function (achievementId) {
            const definition = definitions.find(
                item => item.id === String(achievementId)
            );

            if (!definition) {
                throw new Error("Unknown achievement.");
            }

            const state = syncFromCourseProgress(load());

            if (!state.unlocked.includes(definition.id)) {
                throw new Error(
                    "Complete the required chapter first."
                );
            }

            if (!state.claimed.includes(definition.id)) {
                state.claimed.push(definition.id);
                state.crystals += definition.crystals;
                save(state);
            }

            return buildView(state);
        },

        getTitleOptions: function () {
            const state = syncFromCourseProgress(load());

            return [
                {
                    title: "Cave Explorer",
                    unlocked: true,
                    requirement: "Available from the beginning"
                },
                ...definitions.map(item => ({
                    title: item.titleReward,
                    unlocked: state.claimed.includes(item.id),
                    requirement:
                        `Claim ${item.name} — ${item.courseName} Chapter ${item.chapter}`
                }))
            ];
        },

        getFeatureOptions: function () {
            const state = syncFromCourseProgress(load());

            return [
                {
                    name: "First Steps",
                    unlocked: true,
                    requirement: "Available from the beginning"
                },
                ...definitions.map(item => ({
                    name: item.name,
                    unlocked: state.claimed.includes(item.id),
                    requirement:
                        `Claim the Chapter ${item.chapter} reward`
                }))
            ];
        }
    };
})();
'''

achievement_nav = r'''@inject AchievementService AchievementService

<NavLink class="achievement-nav-link" href="/achievements">
    <span>Achievements</span>

    @if (UnclaimedCount > 0)
    {
        <strong aria-label="@UnclaimedCount unclaimed achievement rewards">
            @UnclaimedCount
        </strong>
    }
</NavLink>

<style>
    .achievement-nav-link {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
    }

    .achievement-nav-link > strong {
        display: grid;
        min-width: 19px;
        height: 19px;
        padding: 0 5px;
        place-items: center;
        color: var(--accent-contrast, #07120b);
        background: var(--accent, #71e49a);
        border-radius: 99px;
        box-shadow: 0 0 14px var(--accent-glow, rgba(113, 228, 154, .4));
        font-size: 9px;
        font-weight: 950;
    }
</style>

@code {
    private int UnclaimedCount;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!firstRender)
        {
            return;
        }

        try
        {
            AchievementState state =
                await AchievementService.GetStateAsync();

            UnclaimedCount = state.UnclaimedCount;
        }
        catch
        {
            UnclaimedCount = 0;
        }

        await InvokeAsync(StateHasChanged);
    }
}
'''

progress_identity = r'''@inject AchievementService AchievementService
@inject ProfileService ProfileService

<NavLink class="progress-identity @(Compact ? "compact" : "")"
         href="/achievements">
    @if (!Compact)
    {
        <span class="identity-emblem" aria-hidden="true">
            @EmblemSymbol
        </span>

        <span class="identity-copy">
            <strong>@Title</strong>
            <small>◆ @State.Crystals Code Crystals</small>
        </span>
    }
    else
    {
        <span class="compact-crystals">◆ @State.Crystals</span>
    }

    @if (State.UnclaimedCount > 0)
    {
        <span class="identity-notification">
            @State.UnclaimedCount
        </span>
    }
</NavLink>

<style>
    .progress-identity {
        display: flex;
        align-items: center;
        gap: 9px;
        margin-top: 10px;
        padding: 10px;
        color: var(--text, #eef4f8);
        text-decoration: none;
        background: var(--surface-raised, #202c38);
        border: 1px solid var(--border, #2b3948);
        border-radius: 9px;
    }

    .progress-identity:hover {
        border-color: var(--accent-border, #3e8a59);
    }

    .progress-identity.compact {
        position: relative;
        width: auto;
        margin: 0;
        padding: 9px 10px;
        color: var(--text-muted, #9ba8b5);
        font-size: 10px;
        font-weight: 900;
    }

    .identity-emblem {
        display: grid;
        width: 34px;
        height: 34px;
        flex: 0 0 34px;
        place-items: center;
        color: var(--accent-contrast, #07120b);
        background: var(--accent, #71e49a);
        border-radius: 9px;
        font-size: 13px;
        font-weight: 950;
    }

    .identity-copy {
        min-width: 0;
        flex: 1;
    }

    .identity-copy strong,
    .identity-copy small {
        display: block;
    }

    .identity-copy strong {
        overflow: hidden;
        font-size: 11px;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .identity-copy small {
        margin-top: 3px;
        color: var(--accent, #71e49a);
        font-size: 9px;
        font-weight: 800;
    }

    .identity-notification {
        display: grid;
        min-width: 19px;
        height: 19px;
        padding: 0 5px;
        place-items: center;
        color: var(--accent-contrast, #07120b);
        background: var(--accent, #71e49a);
        border-radius: 99px;
        font-size: 9px;
        font-weight: 950;
    }

    .compact .identity-notification {
        position: absolute;
        top: -7px;
        right: -7px;
    }
</style>

@code {
    [Parameter]
    public bool Compact { get; set; }

    private ProfilePreferences Profile = new();
    private AchievementState State = new();

    private string Title =>
        string.IsNullOrWhiteSpace(Profile.Title)
            ? "Cave Explorer"
            : Profile.Title;

    private string EmblemSymbol =>
        Profile.Emblem switch
        {
            "cave" => "△",
            "terminal" => ">_",
            "gear" => "⚙",
            _ => "◆"
        };

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!firstRender)
        {
            return;
        }

        try
        {
            Profile = await ProfileService.GetPreferencesAsync();
            State = await AchievementService.GetStateAsync();
        }
        catch
        {
            // Local progression remains optional.
        }

        await InvokeAsync(StateHasChanged);
    }
}
'''

achievements_page = r'''@page "/achievements"
@using System.Linq
@inject AchievementService AchievementService
@inject ProfileService ProfileService

<PageTitle>Achievements · CaveCode Academy</PageTitle>

<div class="achievement-page">
    <header class="achievement-header">
        <div class="header-nav">
            <NavLink href="/">← Academy home</NavLink>
            <NavLink href="/settings">Appearance & profile</NavLink>
        </div>

        <div class="header-copy">
            <div>
                <p class="eyebrow">ACHIEVEMENTS</p>
                <h1>Claim your chapter rewards.</h1>
                <p>
                    Complete chapters, claim Code Crystals, unlock titles,
                    and choose which accomplishment represents your profile.
                </p>
            </div>

            <aside class="crystal-wallet">
                <span>CODE CRYSTALS</span>
                <strong>◆ @State.Crystals</strong>
                <small>Future expansion currency</small>
            </aside>
        </div>
    </header>

    @if (!Ready)
    {
        <main class="loading-achievements">
            Loading achievement progress…
        </main>
    }
    else
    {
        <main class="achievement-content">
            <section class="achievement-summary">
                <div>
                    <span>Earned</span>
                    <strong>@State.EarnedCount / @State.TotalCount</strong>
                </div>
                <div>
                    <span>Claimed</span>
                    <strong>@State.ClaimedCount</strong>
                </div>
                <div class="unclaimed-summary">
                    <span>Rewards waiting</span>
                    <strong>@State.UnclaimedCount</strong>
                </div>
            </section>

            @if (!string.IsNullOrWhiteSpace(Message))
            {
                <div class="achievement-message">@Message</div>
            }

            @foreach (CourseGroup group in CourseGroups)
            {
                <section class="course-achievements">
                    <div class="course-heading">
                        <div>
                            <span class="course-mark">@group.Mark</span>
                            <div>
                                <p>@group.CourseLabel</p>
                                <h2>@group.CourseName</h2>
                            </div>
                        </div>

                        <strong>
                            @group.Achievements.Count(item => item.Claimed)
                            / @group.Achievements.Length claimed
                        </strong>
                    </div>

                    <div class="achievement-grid">
                        @foreach (AchievementRecord achievement in group.Achievements)
                        {
                            <article class="achievement-card @CardClass(achievement)">
                                <div class="achievement-topline">
                                    <span>CHAPTER @achievement.Chapter</span>
                                    <strong>@StatusLabel(achievement)</strong>
                                </div>

                                <div class="achievement-medal">
                                    @(achievement.Claimed ? "✓" : achievement.Unlocked ? "◆" : "🔒")
                                </div>

                                <h3>@achievement.Name</h3>
                                <p>@achievement.Description</p>

                                <div class="reward-list">
                                    <div>
                                        <span>Title</span>
                                        <strong>@achievement.TitleReward</strong>
                                    </div>
                                    <div>
                                        <span>Reward</span>
                                        <strong>◆ @achievement.Crystals</strong>
                                    </div>
                                </div>

                                @if (!achievement.Unlocked)
                                {
                                    <button type="button" disabled>
                                        Complete Chapter @achievement.Chapter
                                    </button>
                                }
                                else if (!achievement.Claimed)
                                {
                                    <button type="button"
                                            class="claim-button"
                                            @onclick="() => Claim(achievement)">
                                        Claim reward
                                    </button>
                                }
                                else
                                {
                                    <div class="claimed-actions">
                                        <button type="button"
                                                @onclick="() => EquipTitle(achievement)">
                                            Equip title
                                        </button>
                                        <button type="button"
                                                @onclick="() => FeatureAchievement(achievement)">
                                            Feature
                                        </button>
                                    </div>
                                }
                            </article>
                        }
                    </div>
                </section>
            }

            <section class="crystal-future">
                <div>
                    <p class="eyebrow">COMING LATER</p>
                    <h2>Use Code Crystals for optional expansions.</h2>
                    <p>
                        Core programming languages remain open. Crystals are
                        reserved for optional project packs, specialist labs,
                        cosmetic themes, emblems, and advanced expansions.
                    </p>
                </div>

                <div class="future-items">
                    <span>Raspberry Pi Lab</span>
                    <span>Industrial Integration Lab</span>
                    <span>Capstone Environments</span>
                </div>
            </section>
        </main>
    }
</div>

<style>
    .achievement-page {
        min-height: 100vh;
        padding: 30px 18px 70px;
        color: var(--text);
        background:
            radial-gradient(
                circle at 10% 0%,
                var(--accent-surface),
                transparent 28%
            ),
            var(--bg);
        font-family: Inter, system-ui, sans-serif;
    }

    .achievement-header,
    .achievement-content,
    .loading-achievements {
        width: min(1120px, 100%);
        margin: 0 auto;
    }

    .header-nav {
        display: flex;
        gap: 10px;
        margin-bottom: 30px;
    }

    .header-nav a {
        padding: 9px 11px;
        color: var(--text-muted);
        text-decoration: none;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 8px;
        font-size: 10px;
        font-weight: 850;
    }

    .header-nav a:hover {
        color: var(--text);
        border-color: var(--accent-border);
    }

    .header-copy {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 30px;
    }

    .header-copy h1 {
        max-width: 720px;
        margin: 0;
        font-size: clamp(38px, 6vw, 66px);
        letter-spacing: -2px;
    }

    .header-copy > div > p:last-child {
        max-width: 680px;
        margin: 14px 0 0;
        color: var(--text-muted);
        line-height: 1.65;
    }

    .eyebrow {
        margin: 0 0 8px;
        color: var(--accent);
        font-size: 10px;
        font-weight: 950;
        letter-spacing: 1.2px;
    }

    .crystal-wallet {
        min-width: 220px;
        padding: 19px;
        color: var(--dark-panel-text, #eef4f8);
        background: var(--code-bg);
        border: 1px solid var(--accent-border);
        border-radius: 14px;
        box-shadow: 0 0 35px var(--accent-glow);
    }

    .crystal-wallet span,
    .crystal-wallet strong,
    .crystal-wallet small {
        display: block;
    }

    .crystal-wallet span,
    .crystal-wallet small {
        color: var(--code-muted, #aab7c4);
        font-size: 9px;
    }

    .crystal-wallet strong {
        margin: 8px 0;
        color: var(--accent);
        font-size: 28px;
    }

    .achievement-content {
        display: grid;
        gap: 20px;
        margin-top: 38px;
    }

    .loading-achievements {
        margin-top: 38px;
        padding: 25px;
        color: var(--text-muted);
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 14px;
    }

    .achievement-summary {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }

    .achievement-summary > div {
        padding: 17px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 12px;
    }

    .achievement-summary span,
    .achievement-summary strong {
        display: block;
    }

    .achievement-summary span {
        color: var(--text-muted);
        font-size: 10px;
    }

    .achievement-summary strong {
        margin-top: 7px;
        font-size: 22px;
    }

    .unclaimed-summary {
        border-color: var(--accent-border) !important;
        box-shadow: inset 0 0 0 1px var(--accent-surface);
    }

    .achievement-message {
        padding: 12px 14px;
        color: var(--accent-soft);
        background: var(--accent-surface);
        border: 1px solid var(--accent-border);
        border-radius: 9px;
        font-size: 11px;
        font-weight: 800;
    }

    .course-achievements {
        padding: 22px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 15px;
        box-shadow: 0 18px 60px var(--shadow);
    }

    .course-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        margin-bottom: 18px;
    }

    .course-heading > div {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .course-mark {
        display: grid;
        width: 48px;
        height: 48px;
        place-items: center;
        color: var(--accent-contrast);
        background: var(--accent);
        border-radius: 12px;
        font-weight: 950;
    }

    .course-heading p,
    .course-heading h2 {
        margin: 0;
    }

    .course-heading p,
    .course-heading > strong {
        color: var(--text-muted);
        font-size: 10px;
    }

    .course-heading h2 {
        margin-top: 3px;
        font-size: 22px;
    }

    .achievement-grid {
        display: grid;
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 10px;
    }

    .achievement-card {
        display: flex;
        min-height: 330px;
        padding: 15px;
        flex-direction: column;
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: 12px;
    }

    .achievement-card.locked {
        opacity: .62;
    }

    .achievement-card.unclaimed {
        border-color: var(--accent-border);
        box-shadow: inset 0 0 0 1px var(--accent-surface);
    }

    .achievement-card.claimed {
        background: linear-gradient(
            145deg,
            var(--surface-soft),
            var(--accent-surface)
        );
    }

    .achievement-topline {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        color: var(--text-muted);
        font-size: 8px;
        font-weight: 900;
        letter-spacing: .5px;
    }

    .achievement-topline strong {
        color: var(--accent);
    }

    .achievement-medal {
        display: grid;
        width: 48px;
        height: 48px;
        margin: 18px 0 14px;
        place-items: center;
        color: var(--accent-contrast);
        background: var(--accent);
        border-radius: 14px;
        box-shadow: 0 0 25px var(--accent-glow);
        font-size: 21px;
        font-weight: 950;
    }

    .locked .achievement-medal {
        color: var(--text-muted);
        background: var(--surface-strong);
        box-shadow: none;
    }

    .achievement-card h3 {
        margin: 0;
        font-size: 16px;
    }

    .achievement-card > p {
        margin: 9px 0 14px;
        color: var(--text-muted);
        font-size: 10px;
        line-height: 1.5;
    }

    .reward-list {
        display: grid;
        gap: 7px;
        margin-top: auto;
    }

    .reward-list > div {
        padding: 8px;
        background: var(--surface-raised);
        border: 1px solid var(--border);
        border-radius: 7px;
    }

    .reward-list span,
    .reward-list strong {
        display: block;
    }

    .reward-list span {
        color: var(--text-dim);
        font-size: 8px;
    }

    .reward-list strong {
        margin-top: 3px;
        font-size: 10px;
    }

    .achievement-card button {
        min-height: 39px;
        margin-top: 11px;
        color: var(--text-muted);
        background: var(--surface-raised);
        border: 1px solid var(--border);
        border-radius: 8px;
        cursor: pointer;
        font-size: 10px;
        font-weight: 850;
    }

    .achievement-card button:disabled {
        cursor: not-allowed;
    }

    .achievement-card .claim-button {
        color: var(--accent-contrast);
        background: var(--accent);
        border-color: var(--accent);
    }

    .claimed-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 7px;
    }

    .crystal-future {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 24px;
        padding: 24px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 15px;
    }

    .crystal-future h2 {
        margin: 0;
    }

    .crystal-future p:last-child {
        max-width: 680px;
        margin: 10px 0 0;
        color: var(--text-muted);
        line-height: 1.55;
    }

    .future-items {
        display: grid;
        gap: 7px;
        min-width: 240px;
    }

    .future-items span {
        padding: 9px 10px;
        color: var(--text-muted);
        background: var(--surface-soft);
        border: 1px solid var(--border);
        border-radius: 8px;
        font-size: 9px;
        font-weight: 800;
    }

    @@media (max-width: 980px) {
        .achievement-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .header-copy,
        .crystal-future {
            align-items: stretch;
            flex-direction: column;
        }

        .crystal-wallet,
        .future-items {
            min-width: 0;
        }
    }

    @@media (max-width: 580px) {
        .achievement-page {
            padding-inline: 10px;
        }

        .achievement-summary,
        .achievement-grid {
            grid-template-columns: 1fr;
        }

        .course-heading {
            align-items: flex-start;
            flex-direction: column;
        }
    }
</style>

@code {
    private AchievementState State = new();
    private ProfilePreferences Profile = new();
    private bool Ready;
    private string Message = "";

    private CourseGroup[] CourseGroups =>
        new[]
        {
            new CourseGroup(
                "C#",
                "C# PATH",
                "C# Cave Adventure",
                State.Achievements
                    .Where(item => item.Course == "csharp")
                    .OrderBy(item => item.Chapter)
                    .ToArray()
            ),
            new CourseGroup(
                "Py",
                "PYTHON PATH",
                "Python Automation Quest",
                State.Achievements
                    .Where(item => item.Course == "python")
                    .OrderBy(item => item.Chapter)
                    .ToArray()
            )
        };

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!firstRender)
        {
            return;
        }

        await Reload();
        Ready = true;
        await InvokeAsync(StateHasChanged);
    }

    private async Task Reload()
    {
        State = await AchievementService.GetStateAsync();
        Profile = await ProfileService.GetPreferencesAsync();
    }

    private async Task Claim(AchievementRecord achievement)
    {
        State = await AchievementService.ClaimAsync(achievement.Id);
        Message =
            $"Claimed {achievement.Name}: +{achievement.Crystals} Code Crystals and title unlocked — {achievement.TitleReward}.";
    }

    private async Task EquipTitle(AchievementRecord achievement)
    {
        Profile = await ProfileService.SetTitleAsync(
            achievement.TitleReward
        );

        Message = $"Equipped title: {achievement.TitleReward}.";
    }

    private async Task FeatureAchievement(
        AchievementRecord achievement
    )
    {
        Profile =
            await ProfileService.SetFeaturedAchievementAsync(
                achievement.Name
            );

        Message = $"Featured achievement: {achievement.Name}.";
    }

    private static string CardClass(
        AchievementRecord achievement
    ) =>
        achievement.Claimed
            ? "claimed"
            : achievement.Unlocked
                ? "unclaimed"
                : "locked";

    private static string StatusLabel(
        AchievementRecord achievement
    ) =>
        achievement.Claimed
            ? "CLAIMED"
            : achievement.Unlocked
                ? "REWARD READY"
                : "LOCKED";

    private sealed record CourseGroup(
        string Mark,
        string CourseLabel,
        string CourseName,
        AchievementRecord[] Achievements
    );
}
'''

services_dir = root / "Services"
services_dir.mkdir(exist_ok=True)
(root / "Services" / "AchievementService.cs").write_text(
    achievement_service,
    encoding="utf-8"
)

js_dir = root / "wwwroot" / "js"
js_dir.mkdir(parents=True, exist_ok=True)
(root / "wwwroot" / "js" / "caveCodeAchievements.js").write_text(
    achievement_js,
    encoding="utf-8"
)

components_dir = root / "Components"
components_dir.mkdir(exist_ok=True)
(root / "Components" / "AchievementNavLink.razor").write_text(
    achievement_nav,
    encoding="utf-8"
)
(root / "Components" / "ProgressIdentity.razor").write_text(
    progress_identity,
    encoding="utf-8"
)

(root / "Pages" / "Achievements.razor").write_text(
    achievements_page,
    encoding="utf-8"
)

# Enforce title and featured-achievement locks in browser storage.
profile_js_path = root / "wwwroot" / "js" / "caveCodeProfile.js"
profile_js = profile_js_path.read_text(encoding="utf-8")

if "sanitizeProgressionLocks" not in profile_js:
    profile_anchor = "    window.caveCodeProfile = {\n"

    sanitize_function = r'''    function sanitizeProgressionLocks(preferences) {
        if (!window.caveCodeAchievements) {
            return preferences;
        }

        const titleOptions =
            window.caveCodeAchievements.getTitleOptions();
        const featureOptions =
            window.caveCodeAchievements.getFeatureOptions();

        const titleAllowed = titleOptions.some(
            option =>
                option.title === preferences.title &&
                option.unlocked
        );

        const featureAllowed = featureOptions.some(
            option =>
                option.name === preferences.featuredAchievement &&
                option.unlocked
        );

        return {
            ...preferences,
            title: titleAllowed
                ? preferences.title
                : "Cave Explorer",
            featuredAchievement: featureAllowed
                ? preferences.featuredAchievement
                : "First Steps"
        };
    }

'''

    if profile_anchor not in profile_js:
        raise SystemExit(
            "Could not find the profile API in caveCodeProfile.js."
        )

    profile_js = profile_js.replace(
        profile_anchor,
        sanitize_function + profile_anchor,
        1
    )

    old_get = '''        getPreferences: function () {
            current = load();

            return {
                ...current
            };
        },'''

    new_get = '''        getPreferences: function () {
            current = sanitizeProgressionLocks(load());
            localStorage.setItem(
                storageKey,
                JSON.stringify(current)
            );

            return {
                ...current
            };
        },'''

    if old_get not in profile_js:
        raise SystemExit(
            "Could not update profile preference loading."
        )

    profile_js = profile_js.replace(
        old_get,
        new_get,
        1
    )

    old_set = '''            current = {
                ...current,
                [name]: normalize(name, value)
            };

            return save();'''

    new_set = '''            const nextValue = normalize(name, value);

            if (
                name === "title" &&
                window.caveCodeAchievements
            ) {
                const allowed =
                    window.caveCodeAchievements
                        .getTitleOptions()
                        .some(
                            option =>
                                option.title === nextValue &&
                                option.unlocked
                        );

                if (!allowed) {
                    throw new Error(
                        "Claim the matching achievement first."
                    );
                }
            }

            if (
                name === "featuredAchievement" &&
                window.caveCodeAchievements
            ) {
                const allowed =
                    window.caveCodeAchievements
                        .getFeatureOptions()
                        .some(
                            option =>
                                option.name === nextValue &&
                                option.unlocked
                        );

                if (!allowed) {
                    throw new Error(
                        "Claim the matching achievement first."
                    );
                }
            }

            current = {
                ...current,
                [name]: nextValue
            };

            return save();'''

    if old_set not in profile_js:
        raise SystemExit(
            "Could not update profile preference validation."
        )

    profile_js = profile_js.replace(
        old_set,
        new_set,
        1
    )

profile_js_path.write_text(profile_js, encoding="utf-8")

# Register the achievement service.
program_path = root / "Program.cs"
program = program_path.read_text(encoding="utf-8")

if "using CaveCode.Services;" not in program:
    program = program.replace(
        "using CaveCode;\n",
        "using CaveCode;\nusing CaveCode.Services;\n",
        1
    )

registration_anchor = (
    "builder.Services.AddScoped(sp => new HttpClient "
    "{ BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });"
)

if registration_anchor not in program:
    raise SystemExit(
        "Could not find the service-registration anchor in Program.cs."
    )

if "AddScoped<AchievementService>()" not in program:
    program = program.replace(
        registration_anchor,
        registration_anchor
        + "\nbuilder.Services.AddScoped<AchievementService>();",
        1
    )

program_path.write_text(program, encoding="utf-8")

# Ensure the services namespace is available to Razor components.
imports_path = root / "_Imports.razor"
imports = imports_path.read_text(encoding="utf-8")

if "@using CaveCode.Services" not in imports:
    if not imports.endswith("\n"):
        imports += "\n"
    imports += "@using CaveCode.Services\n"

imports_path.write_text(imports, encoding="utf-8")

# Load the achievements script before Blazor starts.
index_path = root / "wwwroot" / "index.html"
index = index_path.read_text(encoding="utf-8")

if "js/caveCodeAchievements.js" not in index:
    possible_markers = [
        '<script src="js/caveCodeProfile.js?v=1"></script>',
        '<script src="js/caveCodeTheme.js"></script>',
        '<script src="js/caveCodeAuth.js?v=3"></script>',
        '<script src="js/caveCodeAuth.js"></script>',
    ]

    marker = next(
        (item for item in possible_markers if item in index),
        None
    )

    if marker is None:
        raise SystemExit(
            "Could not find a CaveCode JavaScript insertion point in index.html."
        )

    index = index.replace(
        marker,
        marker
        + '\n    <script src="js/caveCodeAchievements.js?v=1"></script>',
        1
    )

index_path.write_text(index, encoding="utf-8")

# Put Achievements beside Appearance on the homepage.
home_path = root / "Pages" / "Home.razor"
home = home_path.read_text(encoding="utf-8")

if "<AchievementNavLink" not in home:
    home_anchor = '<NavLink href="/settings">Appearance</NavLink>'

    if home_anchor not in home:
        raise SystemExit(
            "Could not find the Appearance link in Pages/Home.razor."
        )

    home = home.replace(
        home_anchor,
        home_anchor + "\n                <AchievementNavLink />",
        1
    )

home_path.write_text(home, encoding="utf-8")

# Put the reusable progression identity in every account panel.
auth_path = root / "Components" / "AuthPanel.razor"
auth = auth_path.read_text(encoding="utf-8")

if "<ProgressIdentity" not in auth:
    auth_anchor = "</section>\n\n<style>"

    if auth_anchor not in auth:
        raise SystemExit(
            "Could not find the AuthPanel closing section."
        )

    auth = auth.replace(
        auth_anchor,
        '    <ProgressIdentity Compact="@Compact" />\n'
        + auth_anchor,
        1
    )

auth_path.write_text(auth, encoding="utf-8")

# Patch Settings so titles and featured achievements remain visible but lock
# until their chapter reward is claimed.
settings_path = root / "Pages" / "Settings.razor"
settings = settings_path.read_text(encoding="utf-8")

if "@inject AchievementService AchievementService" not in settings:
    injection_anchor = "@inject ProfileService ProfileService\n"

    if injection_anchor not in settings:
        raise SystemExit(
            "Run the vanity-profile pass before this achievement pass."
        )

    settings = settings.replace(
        injection_anchor,
        injection_anchor
        + "@inject AchievementService AchievementService\n",
        1
    )

# Replace title dropdown options.
title_loop_pattern = re.compile(
    r'@foreach \(string title in Titles\)\s*\{\s*'
    r'<option value="@title">@title</option>\s*\}',
    re.MULTILINE
)

title_loop_replacement = '''@foreach (TitleUnlockOption option in TitleOptions)
                                {
                                    <option value="@option.Title"
                                            disabled="@(!option.Unlocked)">
                                        @(option.Unlocked
                                            ? option.Title
                                            : $"🔒 {option.Title} — {option.Requirement}")
                                    </option>
                                }'''

settings, title_count = title_loop_pattern.subn(
    title_loop_replacement,
    settings,
    count=1
)

if title_count == 0 and "TitleOptions" not in settings:
    raise SystemExit(
        "Could not find the title dropdown in Settings.razor."
    )

# Replace featured-achievement dropdown options.
achievement_loop_pattern = re.compile(
    r'@foreach \(string achievement in Achievements\)\s*\{\s*'
    r'<option value="@achievement">\s*@achievement\s*</option>\s*\}',
    re.MULTILINE
)

achievement_loop_replacement = '''@foreach (AchievementFeatureOption option in AchievementOptions)
                                {
                                    <option value="@option.Name"
                                            disabled="@(!option.Unlocked)">
                                        @(option.Unlocked
                                            ? option.Name
                                            : $"🔒 {option.Name} — {option.Requirement}")
                                    </option>
                                }'''

settings, achievement_count = achievement_loop_pattern.subn(
    achievement_loop_replacement,
    settings,
    count=1
)

if achievement_count == 0 and "AchievementOptions" not in settings:
    raise SystemExit(
        "Could not find the featured-achievement dropdown in Settings.razor."
    )

if "private TitleUnlockOption[] TitleOptions" not in settings:
    field_anchor = "    private ProfilePreferences Profile = new();\n"

    if field_anchor not in settings:
        raise SystemExit(
            "Could not find the profile field in Settings.razor."
        )

    settings = settings.replace(
        field_anchor,
        field_anchor
        + "    private TitleUnlockOption[] TitleOptions =\n"
          "        Array.Empty<TitleUnlockOption>();\n"
          "    private AchievementFeatureOption[] AchievementOptions =\n"
          "        Array.Empty<AchievementFeatureOption>();\n",
        1
    )

if "await AchievementService.GetTitleOptionsAsync()" not in settings:
    load_anchor = (
        "        Profile =\n"
        "            await ProfileService.GetPreferencesAsync();\n"
    )

    if load_anchor not in settings:
        raise SystemExit(
            "Could not find profile loading in Settings.razor."
        )

    settings = settings.replace(
        load_anchor,
        load_anchor
        + "\n        TitleOptions =\n"
          "            await AchievementService.GetTitleOptionsAsync();\n"
          "\n        AchievementOptions =\n"
          "            await AchievementService.GetFeatureOptionsAsync();\n",
        1
    )

# Validate locked options before saving them.
old_update_title = re.compile(
    r'    private async Task UpdateTitle\(ChangeEventArgs args\)\s*\{.*?\n    \}',
    re.DOTALL
)

new_update_title = '''    private async Task UpdateTitle(ChangeEventArgs args)
    {
        string selected =
            args.Value?.ToString() ?? "Cave Explorer";

        TitleUnlockOption? option =
            TitleOptions.FirstOrDefault(
                item => item.Title == selected
            );

        if (option is null || !option.Unlocked)
        {
            ProfileSaveMessage =
                "Claim the matching chapter achievement first.";
            return;
        }

        Profile = await ProfileService.SetTitleAsync(selected);
        ProfileSaveMessage = "Title saved.";
    }'''

settings, update_title_count = old_update_title.subn(
    new_update_title,
    settings,
    count=1
)

if update_title_count == 0:
    raise SystemExit(
        "Could not update title validation in Settings.razor."
    )

old_update_achievement = re.compile(
    r'    private async Task UpdateAchievement\(ChangeEventArgs args\)\s*\{.*?\n    \}',
    re.DOTALL
)

new_update_achievement = '''    private async Task UpdateAchievement(ChangeEventArgs args)
    {
        string selected =
            args.Value?.ToString() ?? "First Steps";

        AchievementFeatureOption? option =
            AchievementOptions.FirstOrDefault(
                item => item.Name == selected
            );

        if (option is null || !option.Unlocked)
        {
            ProfileSaveMessage =
                "Claim the matching chapter achievement first.";
            return;
        }

        Profile =
            await ProfileService.SetFeaturedAchievementAsync(
                selected
            );

        ProfileSaveMessage = "Featured achievement saved.";
    }'''

settings, update_achievement_count = old_update_achievement.subn(
    new_update_achievement,
    settings,
    count=1
)

if update_achievement_count == 0:
    raise SystemExit(
        "Could not update achievement validation in Settings.razor."
    )

settings_path.write_text(settings, encoding="utf-8")


def patch_course(path: Path, course_key: str) -> None:
    text = path.read_text(encoding="utf-8")

    if "@inject AchievementService AchievementService" not in text:
        inject_anchor = "@inject IJSRuntime JS\n"

        if inject_anchor not in text:
            raise SystemExit(
                f"Could not find IJSRuntime injection in {path}."
            )

        text = text.replace(
            inject_anchor,
            inject_anchor
            + "@inject AchievementService AchievementService\n",
            1
        )

    if "<AchievementNavLink" not in text:
        nav_anchor = (
            '<NavLink href="/settings">⚙ Appearance settings</NavLink>'
        )

        if nav_anchor not in text:
            raise SystemExit(
                f"Could not find course navigation in {path}."
            )

        text = text.replace(
            nav_anchor,
            nav_anchor + "\n            <AchievementNavLink />",
            1
        )

        text = text.replace(
            "grid-template-columns: 1fr 1fr;",
            "grid-template-columns: repeat(3, minmax(0, 1fr));",
            1
        )

    if "private AchievementUnlockResult? ChapterAchievement;" not in text:
        field_anchor = "    private bool ShowChapterOneSignInPrompt;\n"

        if field_anchor not in text:
            raise SystemExit(
                f"Could not find chapter prompt state in {path}."
            )

        text = text.replace(
            field_anchor,
            field_anchor
            + "    private AchievementUnlockResult? ChapterAchievement;\n"
              "    private bool ShowAchievementUnlock;\n"
              "    private bool PendingChapterOneSignInPrompt;\n",
            1
        )

    if "achievement-unlock-overlay" not in text:
        modal_anchor = "@if (ShowChapterOneSignInPrompt)\n"

        if modal_anchor not in text:
            raise SystemExit(
                f"Could not find chapter-one modal in {path}."
            )

        modal = r'''@if (ShowAchievementUnlock && ChapterAchievement is not null)
{
    <div class="achievement-unlock-overlay"
         role="presentation"
         @onclick="DismissAchievementUnlock">
        <section class="achievement-unlock-dialog"
                 role="dialog"
                 aria-modal="true"
                 aria-labelledby="achievement-unlock-title"
                 @onclick:stopPropagation="true">
            <span class="achievement-unlock-kicker">
                CHAPTER @ChapterAchievement.Chapter COMPLETE
            </span>
            <div class="achievement-unlock-medal">◆</div>
            <h2 id="achievement-unlock-title">
                @ChapterAchievement.Name
            </h2>
            <p>@ChapterAchievement.Description</p>

            <div class="achievement-unlock-rewards">
                <div>
                    <span>TITLE REWARD</span>
                    <strong>@ChapterAchievement.TitleReward</strong>
                </div>
                <div>
                    <span>CODE CRYSTALS</span>
                    <strong>◆ @ChapterAchievement.Crystals</strong>
                </div>
            </div>

            <small>
                Reward unlocked. Visit Achievements to claim it.
            </small>

            <div class="achievement-unlock-actions">
                <NavLink href="/achievements">
                    View achievement
                </NavLink>
                <button type="button"
                        @onclick="DismissAchievementUnlock">
                    Continue learning
                </button>
            </div>
        </section>
    </div>
}

'''

        text = text.replace(
            modal_anchor,
            modal + modal_anchor,
            1
        )

    if ".achievement-unlock-overlay" not in text:
        css_anchor = "    .save-progress-overlay {\n"

        if css_anchor not in text:
            raise SystemExit(
                f"Could not find modal CSS in {path}."
            )

        css = r'''    .achievement-unlock-overlay {
        position: fixed;
        inset: 0;
        z-index: 1200;
        display: grid;
        padding: 18px;
        place-items: center;
        background: rgba(3, 7, 10, .84);
        backdrop-filter: blur(8px);
    }

    .achievement-unlock-dialog {
        width: min(520px, 100%);
        padding: 27px;
        color: var(--dark-panel-text, #eef4f8);
        text-align: center;
        background:
            radial-gradient(
                circle at 50% 0%,
                var(--accent-surface),
                transparent 42%
            ),
            var(--code-bg);
        border: 1px solid var(--accent-border);
        border-radius: 17px;
        box-shadow: 0 0 65px var(--accent-glow);
    }

    .achievement-unlock-kicker {
        color: var(--accent);
        font-size: 10px;
        font-weight: 950;
        letter-spacing: 1.2px;
    }

    .achievement-unlock-medal {
        display: grid;
        width: 72px;
        height: 72px;
        margin: 18px auto;
        place-items: center;
        color: var(--accent-contrast);
        background: var(--accent);
        border-radius: 20px;
        box-shadow: 0 0 32px var(--accent-glow);
        font-size: 29px;
    }

    .achievement-unlock-dialog h2 {
        margin: 0;
        font-size: 30px;
    }

    .achievement-unlock-dialog > p {
        margin: 10px auto 18px;
        color: var(--code-muted, #aab7c4);
        line-height: 1.6;
    }

    .achievement-unlock-rewards {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 9px;
    }

    .achievement-unlock-rewards > div {
        padding: 12px;
        background: rgba(255, 255, 255, .045);
        border: 1px solid rgba(255, 255, 255, .09);
        border-radius: 9px;
    }

    .achievement-unlock-rewards span,
    .achievement-unlock-rewards strong {
        display: block;
    }

    .achievement-unlock-rewards span {
        color: var(--code-muted, #aab7c4);
        font-size: 8px;
        letter-spacing: .7px;
    }

    .achievement-unlock-rewards strong {
        margin-top: 5px;
        color: var(--accent-soft);
        font-size: 12px;
    }

    .achievement-unlock-dialog > small {
        display: block;
        margin-top: 14px;
        color: var(--code-muted, #aab7c4);
        font-size: 9px;
    }

    .achievement-unlock-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 9px;
        margin-top: 17px;
    }

    .achievement-unlock-actions a,
    .achievement-unlock-actions button {
        display: grid;
        min-height: 42px;
        place-items: center;
        border-radius: 9px;
        font-size: 10px;
        font-weight: 900;
        text-decoration: none;
        cursor: pointer;
    }

    .achievement-unlock-actions a {
        color: var(--accent-contrast);
        background: var(--accent);
        border: 1px solid var(--accent);
    }

    .achievement-unlock-actions button {
        color: var(--dark-panel-text, #eef4f8);
        background: transparent;
        border: 1px solid var(--border-strong);
    }

'''

        text = text.replace(
            css_anchor,
            css + css_anchor,
            1
        )

    if "HandleChapterCompletionAsync" not in text:
        save_call = "        await SaveProgressAsync();\n"

        if save_call not in text:
            raise SystemExit(
                f"Could not find SaveProgressAsync in {path}."
            )

        text = text.replace(
            save_call,
            save_call
            + f'        await HandleChapterCompletionAsync("{course_key}", finishedModuleIndex);\n',
            1
        )

        old_signin_assignment = (
            "            ShowChapterOneSignInPrompt = !signedIn;\n"
        )

        new_signin_assignment = '''            if (!signedIn)
            {
                if (ShowAchievementUnlock)
                {
                    PendingChapterOneSignInPrompt = true;
                }
                else
                {
                    ShowChapterOneSignInPrompt = true;
                }
            }
'''

        if old_signin_assignment not in text:
            raise SystemExit(
                f"Could not find the chapter-one sign-in assignment in {path}."
            )

        text = text.replace(
            old_signin_assignment,
            new_signin_assignment,
            1
        )

        method_anchor = "    private async Task SaveProgressAsync()\n"

        if method_anchor not in text:
            raise SystemExit(
                f"Could not find SaveProgressAsync method in {path}."
            )

        methods = r'''    private async Task HandleChapterCompletionAsync(
        string course,
        int finishedModuleIndex
    )
    {
        int chapter = ChapterNumberForModule(finishedModuleIndex);

        if (chapter == 0)
        {
            return;
        }

        try
        {
            AchievementUnlockResult? result =
                await AchievementService.UnlockChapterAsync(
                    course,
                    chapter
                );

            if (result is not null && result.NewlyUnlocked)
            {
                ChapterAchievement = result;
                ShowAchievementUnlock = true;
            }
        }
        catch
        {
            // Achievements never interrupt course progression.
        }
    }

    private static int ChapterNumberForModule(int moduleIndex) =>
        moduleIndex is 7 or 15 or 23 or 31 or 39
            ? moduleIndex / 8 + 1
            : 0;

    private void DismissAchievementUnlock()
    {
        ShowAchievementUnlock = false;
        ChapterAchievement = null;

        if (PendingChapterOneSignInPrompt)
        {
            PendingChapterOneSignInPrompt = false;
            ShowChapterOneSignInPrompt = true;
        }
    }

'''

        text = text.replace(
            method_anchor,
            methods + method_anchor,
            1
        )

    path.write_text(text, encoding="utf-8")


patch_course(root / "Pages" / "CSharp.razor", "csharp")
patch_course(root / "Pages" / "Python.razor", "python")

print("CaveCode achievements and Code Crystals pass installed.")
print("Added:")
print("  - 5 C# chapter achievements")
print("  - 5 Python chapter achievements")
print("  - Chapter-completion achievement popups")
print("  - Persistent unclaimed notification badges")
print("  - Claimable Code Crystal rewards")
print("  - Locked progression titles")
print("  - /achievements reward center")
print("  - Cross-course title and crystal identity")
print()
print("Backups saved in .achievements-crystals-backup/")
print("Next command: dotnet build")
